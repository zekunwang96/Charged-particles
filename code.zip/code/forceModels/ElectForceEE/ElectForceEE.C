/*---------------------------------------------------------------------------*\
    CFDEMcoupling - Open Source CFD-DEM coupling

    CFDEMcoupling is part of the CFDEMproject
    www.cfdem.com
                                Christoph Goniva, christoph.goniva@cfdem.com
                                Copyright 2009-2012 JKU Linz
                                Copyright 2012-     DCS Computing GmbH, Linz
-------------------------------------------------------------------------------
License
    This file is part of CFDEMcoupling.

    CFDEMcoupling is free software; you can redistribute it and/or modify it
    under the t erms of the GNU General Public License as published by the
    Free Software Foundation; either version 3 of the License, or (at your
    option) any later version.

    CFDEMcoupling is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with CFDEMcoupling; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Description
    This code is designed to realize coupled CFD-DEM simulations using LIGGGHTS
    and OpenFOAM(R). Note: this code is not part of OpenFOAM(R) (see DISCLAIMER).
\*---------------------------------------------------------------------------*/

#include "error.H"

#include "ElectForceEE.H"
#include "addToRunTimeSelectionTable.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

// * * * * * * * * * * * * * * Static Data M embers * * * * * * * * * * * * * //

defineTypeNameAndDebug(ElectForceEE, 0);

addToRunTimeSelectionTable
(
    forceModel,
    ElectForceEE,
    dictionary
);


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

// Construct from components
ElectForceEE::ElectForceEE
(
    const dictionary& dict,
    cfdemCloud& sm
)
:
    forceModel(dict,sm),
    propsDict_(dict.subDict(typeName + "Props")),  
    epsilonr(readScalar(propsDict_.lookup("epsilonr"))),
    Uphi(readScalar(propsDict_.lookup("Uphi"))),
    partq_(NULL),
    EFieldName_(propsDict_.lookup("EFieldName")),
    E_(sm.mesh().lookupObject<volVectorField> (EFieldName_)),
    EgFieldName_(propsDict_.lookup("EgFieldName")),
    Eg_(sm.mesh().lookupObject<volVectorField> (EgFieldName_))
{

    //Append the field names to be probed
    // suppress particle probe
    if (probeIt_ && propsDict_.found("suppressProbe"))
        probeIt_=!Switch(propsDict_.lookup("suppressProbe"));
    if(probeIt_)
    {
        particleCloud_.probeM().initialize(typeName, typeName+".logDat");
        particleCloud_.probeM().vectorFields_.append("EForce");  //first entry must the be the force
        particleCloud_.probeM().scalarFields_.append("Vp");
        particleCloud_.probeM().writeHeader(); 
    }

   

    // init force sub model
    setForceSubModels(propsDict_);

    // define switches which can be read from dict (default = false)
    forceSubM(0).setSwitchesList(3,true); // activate search for verbose switch

    //set default switches (hard-coded de fault = false)
    forceSubM(0).setSwitches(1,true);       // ElectForceEE only on DEM side (treatForceDEM=true)

    for (int iFSub=0;iFSub<nrForceSubModels();iFSub++)
        forceSubM(iFSub).readSwitches();

    particleCloud_.checkCG(true);
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

ElectForceEE::~ElectForceEE()
{
delete partq_;
}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //
void ElectForceEE::allocateMyArrays() const
{
    // get memory for 2d arrays
    double initVal=0.0;
    particleCloud_.dataExchangeM().allocateArray(partq_,initVal,3);  // field/initVal/with/lenghtFromLigghts


}
void ElectForceEE::manipulateScalarField(volScalarField& EuField) const
{
    // realloc the arrays
    allocateMyArrays();
    
        // reset Scalar field (== means hard reset)
        EuField == dimensionedScalar("zero", EuField.dimensions(), 0.);

        // get DEM data
        particleCloud_.dataExchangeM().getData("q","scalar-atom",partq_);


        particleCloud_.averagingM().setScalarSum2
        (
            EuField,
            partq_,
            particleCloud_.particleWeights(),
            NULL
        );


        forAll(EuField,cellI)
        {
             EuField[cellI] =EuField[cellI]/particleCloud_.mesh().V()[cellI];       
        }

   
}
void ElectForceEE::setForce() const
{
    vector Eforce(0,0,0);
    scalar piBySix(M_PI/6.);
    scalar Vs(0.);
    scalar ds(0.);
    scalar q(0.);
    #include "setupProbeModel.H"
 //  volScalarField EE_(E_&E_);
  // volVectorField Eg(fvc::grad(E_&E_));
  
  for(int index = 0;index <  particleCloud_.numberOfParticles(); ++index)
    {

        label cellI = particleCloud_.cellIDs()[index][0];
       Eforce=vector::zero;

        if (cellI > -1) // particle Found
        {       
              //  vector EEg= EgInterpolator_().interpolate(particleCloud_.position(index),cellI);
              /* interpolation::New(interpolationSchemes_,volPointInterpolation_,U_) */
             //   vector EI= EInterpolator_().interpolate(particleCloud_.position(index),cellI);
                ds = particleCloud_.d(index);
                q  = particleCloud_.charge(index);
          //      scalar rr=sqrt((particleCloud_.position(index)&vector(0,1,0))*(particleCloud_.position(index)&vector(0,1,0))+(particleCloud_.position(index)&vector(0,0,1))*(particleCloud_.position(index)&vector(0,0,1)));
        //        scalar delta=ds/10000;
      //          scalar kap=1.0-0.168*(pos(rr-0.06+0.5*ds+delta)*pos(-q)+pos(-rr+0.02+0.5*ds+delta)*pos(q));              
                scalar dParcel = ds;
                forceSubM(0).scaleDia(dParcel,index); //caution: this fct will scale ds!
                Vs = dParcel*dParcel*dParcel*piBySix;
    //            scalar z0=particleCloud_.position(index)&vector(0,0,1); scalar y0=particleCloud_.position(index)&vector(0,1,0);
  //              vector Es=vector(0,y0,z0)*Uphi/(log(3.0)*(z0*z0+y0*y0)); 
//               vector Egs=-vector(0,y0,z0)*0.5*M_PI*epsilonr*(8.854E-12)*ds*ds*ds*pow((Uphi/log(3.0)),2)/((z0*z0+y0*y0)*(z0*z0+y0*y0));
                //force = kap*q*Es+Egs;
     
               
               Eforce = q*E_[cellI]+0.25*M_PI*ds*ds*ds*epsilonr*Eg_[cellI]*8.854E-12;
               //  Pout << "force = " << force <<"force2 = " << force2 << endl;
                
            

            if(forceSubM(0).verbose() && index >=0 && index <2)
            {
                Pout << "cellI = " << cellI << endl;
                Pout << "index = " << index << endl;
                Pout << "particleCloud_.particleVolume(index) = " << particleCloud_.particleVolume(index) << endl;
                Pout << "Eforce = " << Eforce << endl;
            }

            //Set value fields and write the probe
            if(probeIt_)
            {
                #include "setupProbeModelfields.H"
                // Note: for other than ext one could use vValues.append(x)
                // instead of setSize
                vValues.setSize(vValues.size()+1, Eforce);           //first entry must the be the force
                 sValues.setSize(sValues.size()+1, particleCloud_.particleVolume(index)); 
                particleCloud_.probeM().writeProbe(index, sValues, vValues);
          
               }
        }
    

        forceSubM(0).partToArray(index,Eforce,vector::zero);
         
     
   // write particle based data to global array
//        forceSubM(0).partToArray(index,force,vector::zero);
    }
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// ************************************************************************* //
