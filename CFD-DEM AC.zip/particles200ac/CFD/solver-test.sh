#!/bin/bash
#SBATCH -p paratera
#SBATCH -N 1
#SBATCH -n 16
source ~/soft/OpenFOAM/env.sh
rm -r pro*
decomposePar
yhrun -N 1 -n 16  elecEEac -parallel
#yhrun -p paratera -n 1 reconstructPar # -time 0.00256
#yhrun -p paratera -n 1 foamToVTK # -time 0.00256
