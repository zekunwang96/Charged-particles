#!/bin/bash
#SBATCH -p paratera
#SBATCH -N 1
#SBATCH -n 1
source ~/soft/OpenFOAM/env.sh
yhrun -p paratera -n 1 reconstructPar 
yhrun -p paratera -n 1 foamToVTK 
~                                                    
